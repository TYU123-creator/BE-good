const CURRENT_KEY = "kon_monzaman_current";
      const ACCOUNT_PREFIX = "kon_monzaman_account_";

      let data = null,
        currentCode = null,
        reminderTimer = null;
      let timerSeconds = 0,
        timerInterval = null;
      let alarmInterval = null,
        alarmSet = false,
        alarmTarget = "";
      let currentNoteId = null;
      let audioContext = null;

      /* أدوات عامة */

      function todayKey() {
        const d = new Date();
        return (
          d.getFullYear() +
          "-" +
          String(d.getMonth() + 1).padStart(2, "0") +
          "-" +
          String(d.getDate()).padStart(2, "0")
        );
      }

      function accountKey(c) {
        return ACCOUNT_PREFIX + encodeURIComponent(c);
      }

      function esc(v) {
        return String(v ?? "")
          .replaceAll("&", "&amp;")
          .replaceAll("<", "&lt;")
          .replaceAll(">", "&gt;")
          .replaceAll('"', "&quot;")
          .replaceAll("'", "&#039;");
      }

      function saveData() {
        if (!data || !currentCode) return;
        localStorage.setItem(accountKey(currentCode), JSON.stringify(data));
      }

      function createTask(text = "") {
        return {
          text,
          time: "",
          important: false,
          status: "none",
        };
      }

      function createBox(name, fixed = false) {
        return {
          name,
          fixed,
          tasks: [createTask(), createTask(), createTask()],
        };
      }

      function createDefaultData(username, gender) {
        return {
          version: 11,
          username,
          gender,
          profileImage: "",
          lastDate: todayKey(),
          streak: 0,
          points: 0,
          achievements: [],

          settings: {
            dark: false,
            accent: "#1976d2",
            notifications: false,
            reminderTime: "18:00",
            lastReminder: "",
          },

          student: {
            boxes: [
              createBox("المذاكرة"),
              createBox("الواجبات"),
              createBox("المراجعة"),
              createBox("مهام أخرى"),
              createBox("📌 مهام ثابتة", true),
            ],
          },

          employee: {
            boxes: [
              createBox("مهام العمل"),
              createBox("المشاريع"),
              createBox("الاجتماعات"),
              createBox("مهام أخرى"),
              createBox("📌 مهام ثابتة", true),
            ],
          },

          tables: {
            normal: [],
            task: [],
            weekly: {
              days: [
                "السبت",
                "الأحد",
                "الإثنين",
                "الثلاثاء",
                "الأربعاء",
                "الخميس",
                "الجمعة",
              ],
              periods: ["الصباح", "الظهر", "العصر", "المساء"],
              cells: Array.from({ length: 4 }, () => Array(7).fill("")),
            },
          },

          notes: [
            {
              id: Date.now(),
              title: "ملاحظتي الأولى",
              body: "",
              image: "",
            },
          ],

          archive: [],
        };
      }

      /* ترقية البيانات القديمة */

      function migrateData(o) {
        if (!o || typeof o !== "object") return createDefaultData("مستخدم", "");

        if (!o.settings) o.settings = {};

        Object.assign(o.settings, {
          accent: o.settings.accent || "#1976d2",
          reminderTime: o.settings.reminderTime || "18:00",
          notifications: !!o.settings.notifications,
          dark: !!o.settings.dark,
          lastReminder: o.settings.lastReminder || "",
        });

        if (!o.gender) o.gender = "";
        if (!o.profileImage) o.profileImage = "";

        ["student", "employee"].forEach((type) => {
          if (!o[type]) o[type] = { boxes: [] };
          if (!Array.isArray(o[type].boxes)) o[type].boxes = [];

          const names =
            type === "student"
              ? [
                  "المذاكرة",
                  "الواجبات",
                  "المراجعة",
                  "مهام أخرى",
                  "📌 مهام ثابتة",
                ]
              : [
                  "مهام العمل",
                  "المشاريع",
                  "الاجتماعات",
                  "مهام أخرى",
                  "📌 مهام ثابتة",
                ];

          while (o[type].boxes.length < 5)
            o[type].boxes.push(
              createBox(
                names[o[type].boxes.length],
                o[type].boxes.length === 4,
              ),
            );

          o[type].boxes.forEach((b, i) => {
            b.fixed = i === 4;

            if (!Array.isArray(b.tasks)) b.tasks = [];

            b.tasks.forEach((t) => {
              t.text = t.text || "";
              t.time = t.time || "";
              t.important = !!t.important;
              t.status = t.status || (t.done ? "done" : "none");
            });
          });
        });

        if (!o.tables) o.tables = {};
        if (!Array.isArray(o.tables.normal)) o.tables.normal = [];
        if (!Array.isArray(o.tables.task)) o.tables.task = [];

        if (!o.tables.weekly) o.tables.weekly = {};

        o.tables.weekly.days = [
          "السبت",
          "الأحد",
          "الإثنين",
          "الثلاثاء",
          "الأربعاء",
          "الخميس",
          "الجمعة",
        ];

        if (
          !Array.isArray(o.tables.weekly.periods) ||
          o.tables.weekly.periods.length !== 4
        ) {
          o.tables.weekly.periods = ["الصباح", "الظهر", "العصر", "المساء"];
        }

        if (
          !Array.isArray(o.tables.weekly.cells) ||
          o.tables.weekly.cells.length !== 4
        ) {
          o.tables.weekly.cells = Array.from({ length: 4 }, () =>
            Array(7).fill(""),
          );
        }

        if (!Array.isArray(o.notes)) {
          const old = o.notes || {};

          o.notes = [
            {
              id: Date.now(),
              title: old.title || "",
              body: old.body || "",
              image: "",
            },
          ];
        }

        if (!o.notes.length)
          o.notes.push({
            id: Date.now(),
            title: "ملاحظتي الأولى",
            body: "",
            image: "",
          });

        if (!Array.isArray(o.achievements)) o.achievements = [];

        if (typeof o.points !== "number") o.points = 0;

        if (typeof o.streak !== "number") o.streak = 0;

        if (!o.lastDate) o.lastDate = todayKey();

        return o;
      }

      /* تسجيل الدخول */

      function showRegister() {
        loginBox.classList.add("hidden");
        registerBox.classList.remove("hidden");
      }

      function showLogin() {
        registerBox.classList.add("hidden");
        loginBox.classList.remove("hidden");
      }

      function register() {
        const username = registerUsername.value.trim();
        const gender = registerGender.value;
        const code = registerCode.value;
        const confirm = registerCodeConfirm.value;

        if (!username) return alert("أدخل اسم المستخدم.");

        if (!gender) return alert("حدد الجنس.");

        if (code.length < 3)
          return alert("رمز الدخول يجب أن يكون 3 أحرف أو أرقام على الأقل.");

        if (code !== confirm) return alert("رمزا الدخول غير متطابقين.");

        if (localStorage.getItem(accountKey(code)))
          return alert("هذا الرمز مستخدم بالفعل.");

        data = createDefaultData(username, gender);
        currentCode = code;

        saveData();
        openApp();
      }

      function login() {
        const code = loginCode.value;

        if (!code) return alert("أدخل رمز الدخول.");

        const raw = localStorage.getItem(accountKey(code));

        if (!raw) return alert("رمز الدخول غير صحيح أو الحساب غير موجود.");

        try {
          data = migrateData(JSON.parse(raw));
          currentCode = code;

          openApp();
        } catch (e) {
          alert("حدث خطأ في قراءة البيانات.");
        }
      }

      function openApp() {
        checkNewDay();

        applySettings();

        authScreen.classList.add("hidden");
        app.classList.remove("hidden");

        updateCurrentUser();
        renderAll();
        scheduleNotifications();
        showPage("home");
      }

      function updateCurrentUser() {
        if (data) topUsername.textContent = "👤 " + data.username;
      }

      function showPage(page) {
        document
          .querySelectorAll(".page")
          .forEach((x) => x.classList.add("hidden"));

        const el = document.getElementById(page + "Page");

        if (el) el.classList.remove("hidden");

        if (page === "home") renderHome();
        if (page === "student") renderPerson("student");
        if (page === "employee") renderPerson("employee");
        if (page === "dashboard") renderDashboard();
        if (page === "tables") renderTables();
        if (page === "notes") renderNotes();
        if (page === "settings") renderSettings();
        if (page === "timer") updateTimer();
      }

      function renderAll() {
        renderHome();
        renderPerson("student");
        renderPerson("employee");
        renderDashboard();
        renderTables();
        renderNotes();
        renderSettings();
      }

      /* الإحصائيات */

      function stats(type) {
        let total = 0,
          done = 0,
          stars = 0,
          starsDone = 0;

        data[type].boxes.forEach((b) =>
          b.tasks.forEach((t) => {
            if (!t.text.trim()) return;

            total++;

            if (t.status === "done") done++;

            if (t.important) {
              stars++;

              if (t.status === "done") starsDone++;
            }
          }),
        );

        return { total, done, stars, starsDone };
      }

      function combined() {
        const a = stats("student");
        const b = stats("employee");

        return {
          total: a.total + b.total,
          done: a.done + b.done,
          stars: a.stars + b.stars,
          starsDone: a.starsDone + b.starsDone,
        };
      }

      function renderHome() {
        const s = combined();

        const p = s.total ? Math.round((s.done / s.total) * 100) : 0;

        const sp = s.stars ? Math.round((s.starsDone / s.stars) * 100) : 0;

        homeOverallFill.style.width = p + "%";
        homeOverallText.textContent = p + "%";

        homeStarFill.style.width = sp + "%";
        homeStarText.textContent = sp + "%";
      }

      /* الطالب والموظف */

      function renderPerson(type) {
        const con = document.getElementById(type + "Content");

        const s = stats(type);

        const p = s.total ? Math.round((s.done / s.total) * 100) : 0;

        const sp = s.stars ? Math.round((s.starsDone / s.stars) * 100) : 0;

        let h = `

 <div class="person-progress-area">

 <div class="progress-stats">

 <div class="progress-stat">
 📋 المهام
 <strong>${s.done} / ${s.total}</strong>
 </div>

 <div class="progress-stat">
 ⭐ المميزة
 <strong>${s.starsDone} / ${s.stars}</strong>
 </div>

 <div class="progress-stat">
 📊 الإنجاز
 <strong>${p}%</strong>
 </div>

 <div class="progress-stat">
 🔥 الأيام المتتالية
 <strong>${data.streak}</strong>
 </div>

 </div>

 <div>
 📈 الإنجاز اليومي
 <div class="progress-track">
 <div class="progress-fill" style="width:${p}%"></div>
 </div>
 </div>

 <div>
 ⭐ إنجاز المهام المميزة
 <div class="progress-track">
 <div class="progress-fill" style="width:${sp}%"></div>
 </div>
 </div>

 </div>

 <div class="old-boxes-grid">
 `;

        data[type].boxes.forEach((b, i) => {
          h += renderBox(type, b, i);
        });

        h += `

 </div>

 <div class="person-bottom-stats">

 <div class="info-card">
 <h3>🎯 الهدف اليومي</h3>
 <div class="big-number">${s.total}</div>
 </div>

 <div class="info-card">
 <h3>🔥 السلسلة</h3>
 <div class="big-number">${data.streak}</div>
 </div>

 <div class="info-card">
 <h3>🏆 النقاط</h3>
 <div class="big-number">${data.points}</div>
 </div>

 <div class="info-card">
 <h3>⭐ المميزة</h3>
 <div class="big-number">${s.stars}</div>
 </div>

 </div>
 `;

        con.innerHTML = h;
      }

      function renderBox(type, b, i) {
        let h = `

 <div class="old-task-box ${b.fixed ? "fixed-box" : ""}">

 <div class="box-title-row">

 <input
 class="box-title-input"
 value="${esc(b.name)}"
 onchange="renameBox('${type}',${i},this.value)"
 >

 <button
 class="box-edit"
 onclick="focusBoxName('${type}',${i})"
 >✏️</button>

 </div>
 `;

        b.tasks.forEach((t, j) => {
          h += `

  <div class="inner-task ${t.status === "done" ? "completed" : ""}">

  <input
   class="task-text"
   value="${esc(t.text)}"
   placeholder="اكتب المهمة..."
   onchange="updateTaskText('${type}',${i},${j},this.value)"
  >

  <input
   class="task-time"
   value="${esc(t.time)}"
   placeholder="الفترة الزمنية"
   onchange="updateTaskTime('${type}',${i},${j},this.value)"
  >

  <button
   class="task-button star ${t.important ? "active-star" : ""}"
   onclick="toggleImportant('${type}',${i},${j})"
  >⭐</button>

  <button
   class="task-button done"
   onclick="setTaskStatus('${type}',${i},${j},'done')"
  >🟢</button>

  <button
   class="task-button not-done"
   onclick="setTaskStatus('${type}',${i},${j},'none')"
  >🔴</button>

  <button
   class="task-button delete-task"
   onclick="deleteTask('${type}',${i},${j})"
  >🗑️</button>

  </div>
  `;
        });

        h += `

 <div class="box-footer">

 <button onclick="addTask('${type}',${i})">
 ➕ إضافة مهمة
 </button>

 ${
   b.fixed
     ? "<span style='margin:auto;color:var(--accent);font-weight:bold'>📌 ثابتة</span>"
     : ""
 }

 </div>

 </div>
 `;

        return h;
      }

      function renameBox(t, i, v) {
        data[t].boxes[i].name = v.trim() || `المربع ${i + 1}`;

        saveData();
      }

      function focusBoxName(t, i) {
        renderPerson(t);

        setTimeout(() => {
          document
            .querySelectorAll("#" + t + "Content .box-title-input")
            [i]?.focus();
        }, 20);
      }

      function updateTaskText(t, b, i, v) {
        data[t].boxes[b].tasks[i].text = v;

        saveData();

        renderHome();
        renderPerson(t);
        renderDashboard();
      }

      function updateTaskTime(t, b, i, v) {
        data[t].boxes[b].tasks[i].time = v;

        saveData();
      }

      function toggleImportant(t, b, i) {
        data[t].boxes[b].tasks[i].important =
          !data[t].boxes[b].tasks[i].important;

        saveData();

        renderAll();
      }

      function setTaskStatus(t, b, i, status) {
        const task = data[t].boxes[b].tasks[i];

        const was = task.status === "done";
        const now = status === "done";

        if (was !== now) {
          data.points = Math.max(0, data.points + (now ? 10 : -10));
        }

        task.status = status;

        updateStreak();

        saveData();

        renderAll();

        if (now && !was) motivate();
      }

      function motivate() {
        const messages = [
          "أحسنت! 👏 استمر بهذا الحماس.",
          "رائع! 🌟 مهمة أخرى أُنجزت.",
          "ممتاز! 💪 أنت تقترب من هدفك.",
          "أحسنت الإنجاز! 🏆",
          "استمر، أنت تقوم بعمل رائع! 🚀",
          "خطوة جديدة نحو يوم أكثر تنظيماً! ✨",
        ];

        const x = document.createElement("div");

        x.className = "motivation";

        x.textContent = messages[Math.floor(Math.random() * messages.length)];

        document.body.appendChild(x);

        setTimeout(() => x.remove(), 2500);
      }

      function addTask(t, b) {
        data[t].boxes[b].tasks.push(createTask());

        saveData();

        renderPerson(t);
      }

      function deleteTask(t, b, i) {
        data[t].boxes[b].tasks.splice(i, 1);

        if (!data[t].boxes[b].tasks.length)
          data[t].boxes[b].tasks.push(createTask());

        saveData();

        renderPerson(t);
        renderDashboard();
        renderHome();
      }

      function updateStreak() {
        const s = combined();

        if (s.total && s.done === s.total) {
          const a = "perfect_" + todayKey();

          if (!data.achievements.includes(a)) {
            data.achievements.push(a);
            data.streak++;
            data.points += 25;
          }
        }
      }

      function checkNewDay() {
        if (!data || data.lastDate === todayKey()) return;

        ["student", "employee"].forEach((type) =>
          data[type].boxes.forEach((b, i) => {
            if (i < 4) {
              const tasks = b.tasks.filter((t) => t.text.trim());

              if (tasks.length) {
                data.archive.push({
                  date: data.lastDate,
                  type,
                  boxName: b.name,
                  tasks: JSON.parse(JSON.stringify(tasks)),
                });
              }

              b.tasks = [createTask(), createTask(), createTask()];
            } else {
              b.tasks.forEach((t) => {
                t.status = "none";
              });
            }
          }),
        );

        data.tables.task.forEach((t) =>
          t.cells?.forEach((r) =>
            r.forEach((c) => {
              if (typeof c === "object") {
                c.done = false;
                c.count = 0;
              }
            }),
          ),
        );

        data.lastDate = todayKey();

        saveData();
      }

      /* الجداول */

      function createGrid(rows, cols, task = false) {
        return Array.from({ length: rows }, () =>
          Array.from({ length: cols }, () =>
            task ? { text: "", done: false, count: 0, showControls: true } : "",
          ),
        );
      }

      function addNormalTable() {
        data.tables.normal.push({
          name: "جدول " + (data.tables.normal.length + 1),
          rows: 5,
          cols: 5,
          cells: createGrid(5, 5),
        });

        saveData();
        renderTables();
      }

      function addTaskTable() {
        data.tables.task.push({
          name: "جدول مهام " + (data.tables.task.length + 1),
          rows: 5,
          cols: 5,
          cells: createGrid(5, 5, true),
        });

        saveData();
        renderTables();
      }

      function normalizeTable(t, task) {
        t.rows = t.rows || 5;
        t.cols = t.cols || 5;

        if (!Array.isArray(t.cells)) t.cells = createGrid(t.rows, t.cols, task);

        for (let r = 0; r < t.rows; r++) {
          if (!Array.isArray(t.cells[r])) t.cells[r] = [];

          for (let c = 0; c < t.cols; c++) {
            if (t.cells[r][c] === undefined) {
              t.cells[r][c] = task
                ? { text: "", done: false, count: 0, showControls: true }
                : "";
            }

            if (task && typeof t.cells[r][c] !== "object") {
              t.cells[r][c] = {
                text: String(t.cells[r][c] || ""),
                done: false,
                count: 0,
                showControls: true,
              };
            }
          }
        }
      }

      function renderTables() {
        renderNormalTables();
        renderTaskTables();
        renderWeeklyTable();
      }

      function tableButtons(type, i, copy = false) {
        return `

 <button onclick="addTableRow('${type}',${i})">➕ صف</button>

 <button onclick="removeTableRow('${type}',${i})">➖ صف</button>

 <button onclick="addTableColumn('${type}',${i})">➕ عمود</button>

 <button onclick="removeTableColumn('${type}',${i})">➖ عمود</button>

 ${copy ? `<button onclick="copyTable('${type}',${i})">📋 نسخ</button>` : ""}

 <button onclick="deleteTable('${type}',${i})">🗑️</button>
 `;
      }

      function renderNormalTables() {
        let h = "";

        data.tables.normal.forEach((t, i) => {
          normalizeTable(t, false);

          h += `

  <div class="table-card">

  <div class="table-head">

  <input
   class="table-name"
   value="${esc(t.name)}"
   onchange="renameTable('normal',${i},this.value)"
  >

  ${tableButtons("normal", i, true)}

  </div>

  <div class="table-scroll">

  <table class="custom-table">
  <tbody>

  ${t.cells
    .map(
      (r, ri) => `

   <tr>

   ${r
     .map(
       (c, ci) => `

    <td>
    <textarea
     onchange="updateNormalCell(${i},${ri},${ci},this.value)"
    >${esc(c)}</textarea>
    </td>

   `,
     )
     .join("")}

   </tr>

  `,
    )
    .join("")}

  </tbody>
  </table>

  </div>

  </div>
  `;
        });

        normalTables.innerHTML =
          h || `<div class="info-card">لم تتم إضافة جدول عادي بعد.</div>`;
      }

      function renderTaskTables() {
        let h = "";

        data.tables.task.forEach((t, i) => {
          normalizeTable(t, true);

          let total = 0,
            done = 0;

          t.cells.forEach((r) =>
            r.forEach((c) => {
              if (c.text?.trim()) {
                total++;

                if (c.done) done++;
              }
            }),
          );

          const p = total ? Math.round((done / total) * 100) : 0;

          h += `

  <div class="table-card">

  <div class="table-head">

  <input
   class="table-name"
   value="${esc(t.name)}"
   onchange="renameTable('task',${i},this.value)"
  >

  ${tableButtons("task", i)}

  </div>

  <div>
  📊 ${done} / ${total} — ${p}%

  <div class="progress-track">
   <div class="progress-fill" style="width:${p}%"></div>
  </div>

  </div>

  <div class="task-table-wrapper">

  <div class="task-table-main">

  <div class="table-scroll">

  <table class="custom-table">

  <tbody>

  ${t.cells
    .map(
      (r, ri) => `

   <tr>

   ${r
     .map(
       (c, ci) => `

    <td class="task-cell ${c.done ? "done-cell" : ""}">

    <textarea
     onchange="updateTaskCellText(${i},${ri},${ci},this.value)"
    >${esc(c.text)}</textarea>

    ${
      c.showControls !== false
        ? `

      <div class="task-cell-controls">

      <button
       class="circle-control green-control"
       onclick="taskCellGreen(${i},${ri},${ci})"
      >+</button>

      <span>${c.count || 0}</span>

      <button
       class="circle-control red-control"
       onclick="taskCellRed(${i},${ri},${ci})"
      >−</button>

      <button
       class="hide-cell-controls"
       onclick="toggleCellControls(${i},${ri},${ci})"
      >✕</button>

      </div>

     `
        : `

      <div class="task-cell-controls">

      <button
       class="hide-cell-controls"
       onclick="toggleCellControls(${i},${ri},${ci})"
      >＋ إظهار</button>

      </div>

     `
    }

    </td>

   `,
     )
     .join("")}

   </tr>

  `,
    )
    .join("")}

  </tbody>

  </table>

  </div>

  </div>

  <div class="vertical-progress">

   <div
    class="vertical-progress-fill"
    style="height:${p}%"
   ></div>

  </div>

  </div>

  </div>
  `;
        });

        taskTables.innerHTML =
          h || `<div class="info-card">لم تتم إضافة جدول مهام بعد.</div>`;
      }

      function updateNormalCell(i, r, c, v) {
        data.tables.normal[i].cells[r][c] = v;

        saveData();
      }

      function updateTaskCellText(i, r, c, v) {
        const x = data.tables.task[i].cells[r][c];

        x.text = v;

        if (!v.trim()) {
          x.count = 0;
          x.done = false;
        }

        saveData();

        renderTaskTables();
        renderDashboard();
        renderHome();
      }

      function taskCellGreen(i, r, c) {
        const x = data.tables.task[i].cells[r][c];

        if (!x.text.trim()) return alert("اكتب المهمة أولاً.");

        const wasDone = x.done;

        x.count++;
        x.done = true;

        if (!wasDone) data.points += 5;

        saveData();

        renderTaskTables();
        renderDashboard();
        renderHome();

        motivate();
      }

      function taskCellRed(i, r, c) {
        const x = data.tables.task[i].cells[r][c];

        if (x.count > 0) x.count--;

        x.done = x.count > 0;

        saveData();

        renderTaskTables();
        renderDashboard();
        renderHome();
      }

      function toggleCellControls(i, r, c) {
        const x = data.tables.task[i].cells[r][c];

        x.showControls = x.showControls === false;

        saveData();

        renderTaskTables();
      }

      function addTableRow(type, i) {
        const t = data.tables[type][i];

        t.rows++;

        t.cells.push(
          Array.from({ length: t.cols }, () =>
            type === "task"
              ? { text: "", done: false, count: 0, showControls: true }
              : "",
          ),
        );

        saveData();
        renderTables();
      }

      function removeTableRow(type, i) {
        const t = data.tables[type][i];

        if (t.rows <= 1) return alert("يجب أن يبقى صف واحد على الأقل.");

        t.rows--;
        t.cells.pop();

        saveData();
        renderTables();
      }

      function addTableColumn(type, i) {
        const t = data.tables[type][i];

        t.cols++;

        t.cells.forEach((r) =>
          r.push(
            type === "task"
              ? { text: "", done: false, count: 0, showControls: true }
              : "",
          ),
        );

        saveData();
        renderTables();
      }

      function removeTableColumn(type, i) {
        const t = data.tables[type][i];

        if (t.cols <= 1) return alert("يجب أن يبقى عمود واحد على الأقل.");

        t.cols--;

        t.cells.forEach((r) => r.pop());

        saveData();
        renderTables();
      }

      function renameTable(type, i, v) {
        data.tables[type][i].name = v.trim() || "جدول";

        saveData();
      }

      function copyTable(type, i) {
        const x = JSON.parse(JSON.stringify(data.tables[type][i]));

        x.name += " - نسخة";

        data.tables[type].push(x);

        saveData();
        renderTables();
      }

      function deleteTable(type, i) {
        if (confirm("هل تريد حذف هذا الجدول؟")) {
          data.tables[type].splice(i, 1);

          saveData();
          renderTables();
        }
      }

      function scrollToSection(id) {
        document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
      }

      /* الجدول الأسبوعي */

      function renderWeeklyTable() {
        const w = data.tables.weekly;

        let h = `

 <div class="table-scroll">

 <table class="weekly-table">

 <thead>

 <tr>

 <th>الفترة</th>

 ${w.days.map((x) => `<th>${esc(x)}</th>`).join("")}

 </tr>

 </thead>

 <tbody>
 `;

        for (let r = 0; r < 4; r++) {
          h += `

  <tr>

  <th>

  <input
   class="period-name"
   value="${esc(w.periods[r])}"
   onchange="updatePeriodName(${r},this.value)"
  >

  </th>

  ${w.days
    .map(
      (_, c) => `

   <td>

   <textarea
    onchange="updateWeeklyCell(${r},${c},this.value)"
   >${esc(w.cells[r]?.[c] || "")}</textarea>

   </td>

  `,
    )
    .join("")}

  </tr>
  `;
        }

        weeklyTable.innerHTML = h + "</tbody></table></div>";
      }

      function updatePeriodName(r, v) {
        data.tables.weekly.periods[r] = v.trim() || "فترة";

        saveData();

        renderWeeklyTable();
      }

      function updateWeeklyCell(r, c, v) {
        data.tables.weekly.cells[r][c] = v;

        saveData();
      }

      function copyWeeklyTable() {
        copyText(getWeeklyText(), "تم نسخ الجدول الأسبوعي");
      }

      function getWeeklyText() {
        const w = data.tables.weekly;

        return w.periods
          .map(
            (p, r) =>
              p +
              " : " +
              w.cells[r].map((x, c) => w.days[c] + ": " + x).join(" | "),
          )
          .join("\n");
      }

      /* الملاحظات */

      function renderNotes() {
        notesList.innerHTML = data.notes
          .map(
            (n) => `

   <div
    class="note-card ${n.id === currentNoteId ? "active" : ""}"
    onclick="selectNote(${n.id})"
   >

   <h3>
   📝 ${esc(n.title || "بدون عنوان")}
   </h3>

   <p>
   ${esc((n.body || "").slice(0, 80))}
   </p>

   <div class="note-actions">

   <button
    onclick="event.stopPropagation();
    selectNote(${n.id});
    copyCurrentNote()"
   >📋 نسخ</button>

   <button
    onclick="event.stopPropagation();
    selectNote(${n.id});
    deleteCurrentNote()"
   >🗑️ حذف</button>

   </div>

   </div>

  `,
          )
          .join("");

        if (!currentNoteId && data.notes[0]) currentNoteId = data.notes[0].id;

        const n =
          data.notes.find((x) => x.id === currentNoteId) || data.notes[0];

        if (n) {
          currentNoteId = n.id;

          notesTitle.value = n.title || "";
          notesBody.value = n.body || "";

          noteImagePreview.src = n.image || "";

          noteImagePreview.classList.toggle("hidden", !n.image);
        }
      }

      function selectNote(id) {
        currentNoteId = id;

        renderNotes();
      }

      function newNote() {
        const n = {
          id: Date.now(),
          title: "ملاحظة جديدة",
          body: "",
          image: "",
        };

        data.notes.unshift(n);

        currentNoteId = n.id;

        saveData();

        renderNotes();
      }

      function saveCurrentNote() {
        const n = data.notes.find((x) => x.id === currentNoteId);

        if (!n) return;

        n.title = notesTitle.value;
        n.body = notesBody.value;

        saveData();

        notesSaved.textContent = "✓ تم الحفظ";

        renderNotes();
      }

      function deleteCurrentNote() {
        if (data.notes.length === 1)
          return alert("يجب أن تبقى ملاحظة واحدة على الأقل.");

        if (confirm("هل تريد حذف الملاحظة؟")) {
          data.notes = data.notes.filter((x) => x.id !== currentNoteId);

          currentNoteId = data.notes[0].id;

          saveData();

          renderNotes();
        }
      }

      function copyCurrentNote() {
        const n = data.notes.find((x) => x.id === currentNoteId);

        if (n) copyText(n.title + "\n\n" + n.body, "تم نسخ الملاحظة");
      }

      function copyText(text, msg) {
        if (navigator.clipboard) {
          navigator.clipboard
            .writeText(text)
            .then(() => alert(msg))
            .catch(() => fallbackCopy(text, msg));
        } else {
          fallbackCopy(text, msg);
        }
      }

      function fallbackCopy(text, msg) {
        const a = document.createElement("textarea");

        a.value = text;

        document.body.appendChild(a);

        a.select();

        document.execCommand("copy");

        a.remove();

        alert(msg);
      }

      function addLink() {
        const url = prompt("أدخل الرابط:");

        if (!url) return;

        notesBody.value += "\n" + url + "\n";

        saveCurrentNote();
      }

      function addNoteImage() {
        noteImageInput.click();
      }

      function handleNoteImage(e) {
        const f = e.target.files[0];

        if (!f) return;

        const rd = new FileReader();

        rd.onload = () => {
          const n = data.notes.find((x) => x.id === currentNoteId);

          n.image = rd.result;

          saveData();

          renderNotes();
        };

        rd.readAsDataURL(f);
      }

      /* لوحة التحكم */

      function renderDashboard() {
        const s = stats("student");
        const e = stats("employee");
        const c = combined();

        let tt = 0,
          td = 0;

        data.tables.task.forEach((t) =>
          t.cells.forEach((r) =>
            r.forEach((x) => {
              if (x.text?.trim()) {
                tt++;

                if (x.done) td++;
              }
            }),
          ),
        );

        const p = c.total ? Math.round((c.done / c.total) * 100) : 0;

        dashboardContent.innerHTML = `

 <div class="dashboard-grid">

 ${card("📚", "مهام الطالب", s.done + " / " + s.total)}

 ${card("💼", "مهام الموظف", e.done + " / " + e.total)}

 ${card("📅", "مهام الجداول", td + " / " + tt)}

 ${card("⭐", "المهام المميزة", c.starsDone + " / " + c.stars)}

 ${card("📊", "نسبة الإنجاز", p + "%")}

 ${card("🔥", "الأيام المتتالية", data.streak)}

 ${card("🏆", "المستوى", Math.floor(data.points / 100) + 1)}

 ${card("🎯", "إجمالي المهام", c.total)}

 </div>

 <div class="achievements">

 <h2>🏆 الإنجازات</h2>

 <div class="achievement-list">

 ${
   data.achievements.length
     ? data.achievements
         .map(() => `<div class="achievement">🏆 إنجاز مكتسب</div>`)
         .join("")
     : "<p>ابدأ بإنجاز مهامك للحصول على الإنجازات.</p>"
 }

 </div>

 </div>
 `;
      }

      function card(icon, title, value) {
        return `

 <div class="dashboard-card">

 <div class="icon">${icon}</div>

 <h3>${title}</h3>

 <div class="dashboard-number">
 ${value}
 </div>

 </div>

 `;
      }

      /* الإعدادات والصور */

      function renderSettings() {
        settingsUsername.value = data.username || "";
        settingsGender.value = data.gender || "";

        accentColor.value = data.settings.accent || "#1976d2";

        notificationsToggle.checked = !!data.settings.notifications;

        reminderTime.value = data.settings.reminderTime || "18:00";

        visibleCode.value = currentCode;

        profileImage.src = data.profileImage || "";

        profileImage.classList.toggle("hidden", !data.profileImage);
      }

      function saveProfile() {
        data.username = settingsUsername.value.trim() || data.username;

        data.gender = settingsGender.value;

        saveData();

        updateCurrentUser();

        alert("تم حفظ بيانات الحساب.");
      }

      function handleProfileImage(e) {
        const f = e.target.files[0];

        if (!f) return;

        const rd = new FileReader();

        rd.onload = () => {
          data.profileImage = rd.result;

          saveData();

          renderSettings();
        };

        rd.readAsDataURL(f);
      }

      function toggleCodeVisibility() {
        visibleCode.type =
          visibleCode.type === "password" ? "text" : "password";
      }

      function changeAccent(c) {
        data.settings.accent = c;

        applyAccent(c);

        saveData();

        renderSettings();
      }

      function applyAccent(c) {
        document.documentElement.style.setProperty("--accent", c);

        document.documentElement.style.setProperty(
          "--accent-soft",
          hexRGBA(c, 0.14),
        );

        document.documentElement.style.setProperty(
          "--accent-border",
          hexRGBA(c, 0.35),
        );
      }

      function hexRGBA(h, a) {
        h = h.replace("#", "");

        if (h.length === 3)
          h = h
            .split("")
            .map((x) => x + x)
            .join("");

        return `rgba(
 ${parseInt(h.slice(0, 2), 16)},
 ${parseInt(h.slice(2, 4), 16)},
 ${parseInt(h.slice(4, 6), 16)},
 ${a}
 )`;
      }

      function toggleDarkMode() {
        data.settings.dark = !data.settings.dark;

        applySettings();

        saveData();

        renderSettings();
      }

      function applySettings() {
        document.body.classList.toggle("dark", !!data.settings.dark);

        applyAccent(data.settings.accent || "#1976d2");
      }

      /* الإشعارات */

      function toggleNotifications() {
        if (notificationsToggle.checked && "Notification" in window) {
          Notification.requestPermission().then((p) => {
            if (p !== "granted") {
              notificationsToggle.checked = false;
              data.settings.notifications = false;
            } else {
              data.settings.notifications = true;
            }

            saveData();
            scheduleNotifications();
          });
        } else {
          data.settings.notifications = notificationsToggle.checked;

          saveData();

          scheduleNotifications();
        }
      }

      function saveReminderTime() {
        data.settings.reminderTime = reminderTime.value;

        saveData();

        scheduleNotifications();
      }

      function scheduleNotifications() {
        if (reminderTimer) clearInterval(reminderTimer);

        if (data?.settings.notifications)
          reminderTimer = setInterval(checkReminder, 30000);
      }

      function checkReminder() {
        if (
          !data?.settings.notifications ||
          !("Notification" in window) ||
          Notification.permission !== "granted"
        )
          return;

        const d = new Date();

        const t =
          String(d.getHours()).padStart(2, "0") +
          ":" +
          String(d.getMinutes()).padStart(2, "0");

        if (
          t === data.settings.reminderTime &&
          data.settings.lastReminder !== todayKey()
        ) {
          new Notification("⏰ تذكير من كن منظما", {
            body: "حان وقت مراجعة مهامك اليومية.",
          });

          playAlarmSound();

          data.settings.lastReminder = todayKey();

          saveData();
        }
      }

      /* نظام الصوت */

      function playAlarmSound() {
        try {
          const AudioCtx = window.AudioContext || window.webkitAudioContext;

          if (!AudioCtx) return;

          if (!audioContext) audioContext = new AudioCtx();

          if (audioContext.state === "suspended") audioContext.resume();

          const now = audioContext.currentTime;

          [880, 660, 880, 660].forEach((frequency, index) => {
            const osc = audioContext.createOscillator();

            const gain = audioContext.createGain();

            osc.type = "sine";

            osc.frequency.value = frequency;

            gain.gain.setValueAtTime(0.0001, now + index * 0.22);

            gain.gain.exponentialRampToValueAtTime(
              0.35,
              now + index * 0.22 + 0.03,
            );

            gain.gain.exponentialRampToValueAtTime(
              0.0001,
              now + index * 0.22 + 0.18,
            );

            osc.connect(gain);
            gain.connect(audioContext.destination);

            osc.start(now + index * 0.22);
            osc.stop(now + index * 0.22 + 0.2);
          });
        } catch (e) {
          console.log("تعذر تشغيل الصوت", e);
        }
      }

      /* المؤقت */

      function formatTime(s) {
        return (
          String(Math.floor(s / 3600)).padStart(2, "0") +
          ":" +
          String(Math.floor((s % 3600) / 60)).padStart(2, "0") +
          ":" +
          String(s % 60).padStart(2, "0")
        );
      }

      function updateTimer() {
        timerDisplay.textContent = formatTime(timerSeconds);

        if (timerSeconds <= 0 && timerInterval) {
          clearInterval(timerInterval);

          timerInterval = null;

          timerStatus.textContent = "⏰ انتهى المؤقت!";

          playAlarmSound();

          motivate();

          alert("⏰ انتهى المؤقت!");
        }
      }

      function setTimer() {
        const m = Number(timerMinutes.value);

        if (!m || m < 1) return alert("أدخل عدد الدقائق.");

        pauseTimer();

        timerSeconds = Math.floor(m * 60);

        timerStatus.textContent = "⏳ تم تحديد المؤقت لمدة " + m + " دقيقة";

        updateTimer();
      }

      function startTimer() {
        if (timerInterval || timerSeconds <= 0) return;

        /* محاولة تفعيل الصوت بعد تفاعل المستخدم */

        try {
          const AudioCtx = window.AudioContext || window.webkitAudioContext;

          if (AudioCtx) {
            if (!audioContext) audioContext = new AudioCtx();

            if (audioContext.state === "suspended") audioContext.resume();
          }
        } catch (e) {}

        timerStatus.textContent = "▶️ المؤقت يعمل الآن";

        timerInterval = setInterval(() => {
          timerSeconds--;

          updateTimer();
        }, 1000);
      }

      function pauseTimer() {
        clearInterval(timerInterval);

        timerInterval = null;

        if (timerSeconds > 0) timerStatus.textContent = "⏸️ تم إيقاف المؤقت";
      }

      function resetTimer() {
        pauseTimer();

        timerSeconds = 0;

        timerStatus.textContent = "";

        updateTimer();
      }

      /* المنبه */

      function setAlarm() {
        const t = alarmTime.value;

        if (!t) return alert("حدد وقت المنبه.");

        /* تفعيل الصوت من خلال ضغط المستخدم */

        try {
          const AudioCtx = window.AudioContext || window.webkitAudioContext;

          if (AudioCtx) {
            if (!audioContext) audioContext = new AudioCtx();

            if (audioContext.state === "suspended") audioContext.resume();
          }
        } catch (e) {}

        alarmSet = true;
        alarmTarget = t;

        alarmStatus.textContent = "🔔 المنبه مفعل على " + t;

        if (alarmInterval) clearInterval(alarmInterval);

        alarmInterval = setInterval(checkAlarm, 1000);
      }

      function checkAlarm() {
        if (!alarmSet) return;

        const d = new Date();

        const now =
          String(d.getHours()).padStart(2, "0") +
          ":" +
          String(d.getMinutes()).padStart(2, "0");

        if (now === alarmTarget) {
          alarmSet = false;

          alarmStatus.textContent = "⏰ تم تشغيل المنبه.";

          playAlarmSound();

          motivate();

          alert("⏰ حان وقت المنبه!");
        }
      }

      function cancelAlarm() {
        alarmSet = false;

        alarmTarget = "";

        if (alarmInterval) {
          clearInterval(alarmInterval);

          alarmInterval = null;
        }

        alarmStatus.textContent = "❌ تم إلغاء المنبه.";
      }

      /* تغيير الرمز */

      function changeCode() {
        const old = oldCode.value;
        const nw = newCode.value;
        const cf = newCodeConfirm.value;

        if (old !== currentCode) return alert("رمز الدخول الحالي غير صحيح.");

        if (nw.length < 3) return alert("الرمز الجديد قصير جداً.");

        if (nw !== cf) return alert("الرمزان غير متطابقين.");

        if (localStorage.getItem(accountKey(nw)))
          return alert("هذا الرمز مستخدم بالفعل.");

        const oldKey = accountKey(currentCode);

        currentCode = nw;

        localStorage.setItem(accountKey(nw), JSON.stringify(data));

        localStorage.removeItem(oldKey);

        visibleCode.value = currentCode;

        oldCode.value = "";
        newCode.value = "";
        newCodeConfirm.value = "";

        alert("تم تغيير رمز الدخول بنجاح.");
      }

      /* البيانات */

      function exportData() {
        const blob = new Blob([JSON.stringify(data, null, 2)], {
          type: "application/json",
        });

        const a = document.createElement("a");

        a.href = URL.createObjectURL(blob);

        a.download = "كن-منظما-بيانات.json";

        a.click();

        setTimeout(() => {
          URL.revokeObjectURL(a.href);
        }, 1000);
      }

      function importData(e) {
        const f = e.target.files[0];

        if (!f) return;

        const r = new FileReader();

        r.onload = () => {
          try {
            data = migrateData(JSON.parse(r.result));

            saveData();

            applySettings();

            renderAll();

            alert("تم استيراد البيانات بنجاح.");
          } catch (x) {
            alert("ملف البيانات غير صالح.");
          }
        };

        r.readAsText(f);
      }

      function deleteAccount() {
        if (!confirm("هل أنت متأكد من حذف الحساب وجميع البيانات؟")) return;

        localStorage.removeItem(accountKey(currentCode));

        data = null;
        currentCode = null;

        app.classList.add("hidden");
        authScreen.classList.remove("hidden");

        showLogin();
      }

      function logout() {
        data = null;
        currentCode = null;

        app.classList.add("hidden");
        authScreen.classList.remove("hidden");

        loginCode.value = "";

        showLogin();
      }

      /* لا يوجد دخول تلقائي */

      window.addEventListener("DOMContentLoaded", () => {
        /* يجب إدخال الرمز في كل مرة */
      });
